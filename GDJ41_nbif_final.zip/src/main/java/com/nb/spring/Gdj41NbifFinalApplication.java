package com.nb.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Gdj41NbifFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(Gdj41NbifFinalApplication.class, args);
	}

}
